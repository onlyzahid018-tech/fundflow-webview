package com.fundflowofficial.fundflow

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val webView = WebView(this)
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()

        webView.loadUrl("https://fundflowofficials.netlify.app")
    }

    override fun onBackPressed() {
        val webView = findViewById<WebView?>(android.R.id.content)
        if (webView != null && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }
}
